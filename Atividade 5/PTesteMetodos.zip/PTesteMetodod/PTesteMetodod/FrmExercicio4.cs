﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodod
{
    public partial class FrmExercicio4 : Form
    {
        public FrmExercicio4()
        {
            InitializeComponent();
        }

        private void btnCalcularNum_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int contNum = 0;

            while (contador < rchTxtFrase.Text.Length)
            {
                if(char.IsNumber(rchTxtFrase.Text[contador]))
                {
                    contNum++;
                }
                contador++;
            }
            MessageBox.Show("Possui " + contNum + " caracteres numéricos!");
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int contWhiteSpace = 0;

            while (contador < rchTxtFrase.Text.Length)
            {
                if (char.IsWhiteSpace(rchTxtFrase.Text[contador]))
                {
                    contWhiteSpace++;
                }
                contador++;
            }

            MessageBox.Show("Possui " + contWhiteSpace + " espaços em branco!");
        }
    
        private void btnCalcularAlfa_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int contLetras = 0;

            while (contador < rchTxtFrase.Text.Length)
            {
                if (char.IsLetter(rchTxtFrase.Text[contador]))
                {
                    contLetras++;
                }
                contador++;
            }
            MessageBox.Show("Possui " + contLetras + " caracteres alfabéticos!");
        }
    }
}
