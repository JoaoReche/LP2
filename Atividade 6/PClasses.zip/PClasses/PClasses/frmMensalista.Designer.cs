﻿namespace PClasses
{
    partial class frmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblMatricula = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.LblSalarioMensal = new System.Windows.Forms.Label();
            this.LblDataEntrada = new System.Windows.Forms.Label();
            this.TxtMatricula = new System.Windows.Forms.TextBox();
            this.TxtNome = new System.Windows.Forms.TextBox();
            this.TxtSalarioMensal = new System.Windows.Forms.TextBox();
            this.TxtDataEntrada = new System.Windows.Forms.TextBox();
            this.BtnInstanciar = new System.Windows.Forms.Button();
            this.BtnInstanciarParametros = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LblMatricula
            // 
            this.LblMatricula.AutoSize = true;
            this.LblMatricula.Location = new System.Drawing.Point(12, 9);
            this.LblMatricula.Name = "LblMatricula";
            this.LblMatricula.Size = new System.Drawing.Size(73, 20);
            this.LblMatricula.TabIndex = 0;
            this.LblMatricula.Text = "Matrícula";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(12, 48);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(51, 20);
            this.lblNome.TabIndex = 1;
            this.lblNome.Text = "Nome";
            // 
            // LblSalarioMensal
            // 
            this.LblSalarioMensal.AutoSize = true;
            this.LblSalarioMensal.Location = new System.Drawing.Point(12, 86);
            this.LblSalarioMensal.Name = "LblSalarioMensal";
            this.LblSalarioMensal.Size = new System.Drawing.Size(113, 20);
            this.LblSalarioMensal.TabIndex = 2;
            this.LblSalarioMensal.Text = "Salário Mensal";
            // 
            // LblDataEntrada
            // 
            this.LblDataEntrada.AutoSize = true;
            this.LblDataEntrada.Location = new System.Drawing.Point(12, 124);
            this.LblDataEntrada.Name = "LblDataEntrada";
            this.LblDataEntrada.Size = new System.Drawing.Size(217, 20);
            this.LblDataEntrada.TabIndex = 3;
            this.LblDataEntrada.Text = "Data de Entrada na Empresa";
            // 
            // TxtMatricula
            // 
            this.TxtMatricula.Location = new System.Drawing.Point(235, 9);
            this.TxtMatricula.Name = "TxtMatricula";
            this.TxtMatricula.Size = new System.Drawing.Size(231, 26);
            this.TxtMatricula.TabIndex = 4;
            // 
            // TxtNome
            // 
            this.TxtNome.Location = new System.Drawing.Point(235, 45);
            this.TxtNome.Name = "TxtNome";
            this.TxtNome.Size = new System.Drawing.Size(231, 26);
            this.TxtNome.TabIndex = 5;
            // 
            // TxtSalarioMensal
            // 
            this.TxtSalarioMensal.Location = new System.Drawing.Point(235, 83);
            this.TxtSalarioMensal.Name = "TxtSalarioMensal";
            this.TxtSalarioMensal.Size = new System.Drawing.Size(231, 26);
            this.TxtSalarioMensal.TabIndex = 6;
            // 
            // TxtDataEntrada
            // 
            this.TxtDataEntrada.Location = new System.Drawing.Point(235, 121);
            this.TxtDataEntrada.Name = "TxtDataEntrada";
            this.TxtDataEntrada.Size = new System.Drawing.Size(231, 26);
            this.TxtDataEntrada.TabIndex = 7;
            // 
            // BtnInstanciar
            // 
            this.BtnInstanciar.Location = new System.Drawing.Point(16, 170);
            this.BtnInstanciar.Name = "BtnInstanciar";
            this.BtnInstanciar.Size = new System.Drawing.Size(203, 113);
            this.BtnInstanciar.TabIndex = 8;
            this.BtnInstanciar.Text = "Instanciar Mensalista";
            this.BtnInstanciar.UseVisualStyleBackColor = true;
            this.BtnInstanciar.Click += new System.EventHandler(this.BtnInstanciar_Click);
            // 
            // BtnInstanciarParametros
            // 
            this.BtnInstanciarParametros.Location = new System.Drawing.Point(235, 170);
            this.BtnInstanciarParametros.Name = "BtnInstanciarParametros";
            this.BtnInstanciarParametros.Size = new System.Drawing.Size(373, 113);
            this.BtnInstanciarParametros.TabIndex = 9;
            this.BtnInstanciarParametros.Text = "Instanciar Mensalista Passando Parâmetros";
            this.BtnInstanciarParametros.UseVisualStyleBackColor = true;
            // 
            // frmMensalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1053, 668);
            this.Controls.Add(this.BtnInstanciarParametros);
            this.Controls.Add(this.BtnInstanciar);
            this.Controls.Add(this.TxtDataEntrada);
            this.Controls.Add(this.TxtSalarioMensal);
            this.Controls.Add(this.TxtNome);
            this.Controls.Add(this.TxtMatricula);
            this.Controls.Add(this.LblDataEntrada);
            this.Controls.Add(this.LblSalarioMensal);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.LblMatricula);
            this.Name = "frmMensalista";
            this.Text = "frmMensalista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblMatricula;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label LblSalarioMensal;
        private System.Windows.Forms.Label LblDataEntrada;
        private System.Windows.Forms.TextBox TxtMatricula;
        private System.Windows.Forms.TextBox TxtNome;
        private System.Windows.Forms.TextBox TxtSalarioMensal;
        private System.Windows.Forms.TextBox TxtDataEntrada;
        private System.Windows.Forms.Button BtnInstanciar;
        private System.Windows.Forms.Button BtnInstanciarParametros;
    }
}